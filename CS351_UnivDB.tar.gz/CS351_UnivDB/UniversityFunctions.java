import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import java.sql.*;

public class UniversityFunctions {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String menuItem = "0";//string storing user input
		Scanner input = new Scanner(System.in);//user input source
		
		Class.forName("org.sqlite.JDBC");
		//connect to our university database
		Connection db_conn = DriverManager.getConnection("jdbc:sqlite:UnivDB.db");
		//prepare for sql statements
		Statement stmt = db_conn.createStatement();
		
		ResultSet rs;
		
		//********************start menu system********************
		while(!menuItem.toUpperCase().equals("EXIT")){//loop until user input matches EXIT
				System.out.println("Menu: STU, FAC, Input Custom Select Query, EXIT");
				menuItem = input.nextLine();//get user input for main menu
				
				//********************start student menu********************
				if(menuItem.toUpperCase().equals("STU")){
						while(!menuItem.toUpperCase().equals("EXIT")){//Loop in student menu until user input matches EXIT
							System.out.println("Student Menu: ADD, REMOVE, FIND, ENROLL, WITHDRAW, SCHEDULE, EXIT");
							menuItem = input.nextLine();//get user input for student menu
							//handle ADD menu item for student
							if(menuItem.toUpperCase().startsWith("ADD ")) stmt.executeUpdate("INSERT INTO Student VALUES ("+menuItem.substring(4)+")");
							//handle REMOVE menu item for student
							else if(menuItem.toUpperCase().startsWith("REMOVE ")) stmt.executeUpdate("DELETE FROM Student WHERE StudentID = "+menuItem.substring(7));
							//handle FIND menu item for student
							else if(menuItem.toUpperCase().startsWith("FIND ")){
								//find student by ID or else by name
								if(menuItem.substring(5).matches("[0-9]+"))
									rs = stmt.executeQuery("SELECT * FROM Student WHERE StudentID = "+menuItem.substring(5));
								else
									rs = stmt.executeQuery("SELECT * FROM Student WHERE StudentName = "+menuItem.substring(5));
								
								//get meta data for query
								ResultSetMetaData rsmd = rs.getMetaData();
								//gets the number of columns from meta data
								int col = rsmd.getColumnCount();
								//print out column names from meta data
								for(int i = 1; i < col; i++){
									System.out.print(rsmd.getColumnLabel(i)+"  "); 
								}
								System.out.println(rsmd.getColumnLabel(col)+"  ");
								//print out all rows
							    while (rs.next())
							    {
							    	for(int i = 1; i < col; i++){
							    		System.out.print(rs.getString(i)+"  ");
							    	}
							    	System.out.println(rs.getString(col)+"  ");
							    }
							}
							//handle ENROLL menu item for student
							if(menuItem.toUpperCase().startsWith("ENROLL ")) stmt.executeUpdate("INSERT INTO Enroll VALUES ("+menuItem.substring(7)+")");
							//handle WITHDRAW menu item for student
							else if(menuItem.toUpperCase().startsWith("WITHDRAW ")){
								int success = stmt.executeUpdate("DELETE FROM Enroll WHERE StudentID = "+menuItem.substring(9, menuItem.indexOf(32, 9))+" AND CourseNum ="+menuItem.substring(menuItem.indexOf(32, 9)));
								if(success == 0)System.err.println("Error: StudentID, CourseNum combination not in table.");
							}
							//handle SCHEDULE menu item for student
							else if(menuItem.toUpperCase().startsWith("SCHEDULE ")){
								//find courses by StudentID or else by Student's name
								if(menuItem.substring(9).matches("[0-9]+"))
									rs = stmt.executeQuery("SELECT * FROM Enroll NATURAL JOIN Course WHERE StudentID = "+menuItem.substring(9));
								else
									rs = stmt.executeQuery("SELECT CourseNum, DeptID, CourseName, Location, MeetDay, MeetTime, StudentName FROM Student NATURAL JOIN Enroll NATURAL JOIN Course WHERE StudentName = "+menuItem.substring(9));
								
								//get meta data for query
								ResultSetMetaData rsmd = rs.getMetaData();
								//gets the number of columns from meta data
								int col = rsmd.getColumnCount();
								//print out column names from meta data
								for(int i = 1; i < col; i++){
									System.out.print(rsmd.getColumnLabel(i)+"  "); 
								}
								System.out.println(rsmd.getColumnLabel(col)+"  ");
								//print out all rows
							    while (rs.next())
							    {
							    	for(int i = 1; i < col; i++){
							    		System.out.print(rs.getString(i)+"  ");
							    	}
							    	System.out.println(rs.getString(col)+"  ");
							    }
							}
							//error for unhandled input
							else if(!menuItem.toUpperCase().equals("EXIT")) System.out.println("Error: Invalid entry.");
						}
						menuItem = "0";//reset menuItem to 0;
				}
				//--------------------End student menu--------------------
				//********************start faculty menu********************
				else if(menuItem.toUpperCase().equals("FAC")){
					while(!menuItem.toUpperCase().equals("EXIT")){//loop in faculty menu until user input matches EXIT
						System.out.println("Faculty Menu: ADD, REMOVE, FIND, SCHEDULE, GRANTS, EXIT");
						menuItem = input.nextLine();//get user input for faculty menu
						//handle ADD menu item for faculty
						if(menuItem.toUpperCase().startsWith("ADD ")) stmt.executeUpdate("INSERT INTO Faculty VALUES ("+menuItem.substring(4)+")");
						//handle REMOVE menu item for faculty
						else if(menuItem.toUpperCase().startsWith("REMOVE ")) stmt.executeUpdate("DELETE FROM Faculty WHERE FacultyID = "+menuItem.substring(7));
						//handle FIND menu item for faculty
						else if(menuItem.toUpperCase().startsWith("FIND ")){
							//find faculty by ID or else by name
							if(menuItem.substring(5).matches("[0-9]+"))
								rs = stmt.executeQuery("SELECT * FROM Faculty WHERE FacultyID = "+menuItem.substring(5));
							else
								rs = stmt.executeQuery("SELECT * FROM Faculty WHERE Name = "+menuItem.substring(5));
							
							//get meta data for query
							ResultSetMetaData rsmd = rs.getMetaData();
							//gets the number of columns from meta data
							int col = rsmd.getColumnCount();
							//print out column names from meta data
							for(int i = 1; i < col; i++){
								System.out.print(rsmd.getColumnLabel(i)+"  "); 
							}
							System.out.println(rsmd.getColumnLabel(col)+"  ");
							//print out all rows
						    while (rs.next())
						    {
						    	for(int i = 1; i < col; i++){
						    		System.out.print(rs.getString(i)+"  ");
						    	}
						    	System.out.println(rs.getString(col)+"  ");
						    }
						}
						
						//handle SCHEDULE menu item for faculty
						else if(menuItem.toUpperCase().startsWith("SCHEDULE ")){
							//find courses by Instructor or else by Instructor's name
							if(menuItem.substring(9).matches("[0-9]+"))
								rs = stmt.executeQuery("SELECT * FROM Course WHERE Instructor = "+menuItem.substring(9));
							else
								rs = stmt.executeQuery("SELECT CourseNum, DeptID, CourseName, Location, MeetDay, MeetTime, Name FROM Faculty, Course WHERE Instructor=FacultyID AND Name = "+menuItem.substring(9));
							
							//get meta data for query
							ResultSetMetaData rsmd = rs.getMetaData();
							//gets the number of columns from meta data
							int col = rsmd.getColumnCount();
							//print out column names from meta data
							for(int i = 1; i < col; i++){
								System.out.print(rsmd.getColumnLabel(i)+"  "); 
							}
							System.out.println(rsmd.getColumnLabel(col)+"  ");
							//print out all rows
						    while (rs.next())
						    {
						    	for(int i = 1; i < col; i++){
						    		System.out.print(rs.getString(i)+"  ");
						    	}
						    	System.out.println(rs.getString(col)+"  ");
						    }
						}
						//handle GRANTS menu item for faculty
						else if(menuItem.toUpperCase().startsWith("GRANTS ")){
							//find grants by facultyID or else by name
							if(menuItem.substring(7).matches("[0-9]+"))
								rs = stmt.executeQuery("SELECT * FROM AwardGrant NATURAL JOIN Awarded WHERE FacultyID = "+menuItem.substring(7));
							else
								rs = stmt.executeQuery("SELECT AwardNum, Begin, Finish, AwardAmount, AmountLeft, AwardGrant.AwardNum, Name, AwardTitle FROM AwardGrant NATURAL JOIN Awarded NATURAL JOIN Faculty WHERE Name = "+menuItem.substring(7));
							
							//get meta data for query
							ResultSetMetaData rsmd = rs.getMetaData();
							//gets the number of columns from meta data
							int col = rsmd.getColumnCount();
							//print out column names from meta data
							for(int i = 1; i < col; i++){
								System.out.print(rsmd.getColumnLabel(i)+"  "); 
							}
							System.out.println(rsmd.getColumnLabel(col)+"  ");
							//print out all rows
						    while (rs.next())
						    {
						    	for(int i = 1; i < col; i++){
						    		System.out.print(rs.getString(i)+"  ");
						    	}
						    	System.out.println(rs.getString(col)+"  ");
						    }
						}
						//error for unhandled input
						else if(!menuItem.toUpperCase().equals("EXIT")) System.out.println("Error: Invalid entry.");
					}
					menuItem = "0";//reset menuItem to 0;
				}
				//--------------------End faculty menu--------------------
				//********************start custom select query********************
				else if(menuItem.toUpperCase().startsWith("SELECT ")){
					long start = System.nanoTime();
					rs = stmt.executeQuery(menuItem);
					long finish = System.nanoTime();
					//get meta data for query
					ResultSetMetaData rsmd = rs.getMetaData();
					//gets the number of columns from meta data
					int col = rsmd.getColumnCount();
					//print out column names from meta data
					for(int i = 1; i < col; i++){
						System.out.print(rsmd.getColumnLabel(i)+"  "); 
					}
					System.out.println(rsmd.getColumnLabel(col)+"  ");
					//print out all rows
				    while (rs.next())
				    {
				    	for(int i = 1; i < col; i++){
				    		System.out.print(rs.getString(i)+"  ");
				    	}
				    	System.out.println(rs.getString(col)+"  ");
				    }
				    System.out.println("query time: "+(finish-start)+" ns");
				}
				//--------------------End custom select query--------------------
				//********************error for unhandled input********************
				else if(!menuItem.toUpperCase().equals("EXIT")) System.out.println("Error: Invalid entry.");
		}
		//--------------------End of menu system--------------------

	}

}
